INSERT INTO exercise
VALUES( "bench press", "breast exercise", "120kg x 3", "100kg x3", "70", "5", "3", NULL, NULL);

INSERT INTO exercise
VALUES( "squats", "leg exercise", "160kg x 3", "120kg x3", "90", "5", "3", NULL, NULL);

INSERT INTO exercise
VALUES("jogging", "endurence training", "10km", "12 km", NULL,  NULL, NULL, "10km", "65 min");

INSERT INTO workout
VALUES(15, "Strength exercise", TRUE, "16.03.2017", 60, "average", "good", "upper body strength exercises", NULL, "good", "none");

INSERT INTO workout
VALUES(16, "Endurance ecercise", TRUE, "17.03.2017", 70, "average", "average", "endurance exercise", "sunny, warm temperature", NULL,NULL);
